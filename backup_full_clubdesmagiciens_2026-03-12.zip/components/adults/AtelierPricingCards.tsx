"use client";

import { useState } from "react";
import { Sparkles, Star, PlayCircle, ShieldCheck, Crown } from "lucide-react";
import SubscribeButton from "@/components/SubscribeButton";

export default function AtelierPricingCards({
    monthlyProduct,
    yearlyProduct,
    userLoggedIn
}: {
    monthlyProduct: any;
    yearlyProduct: any;
    userLoggedIn: boolean
}) {
    return (
        <div className="flex flex-col lg:flex-row gap-6 lg:gap-8 items-stretch w-full max-w-5xl mx-auto">

            {/* PASS ESSENTIEL - LEFT SIDE */}
            <div className="relative group flex-1 flex flex-col justify-end overflow-hidden origin-bottom">
                <div className="bg-white/[0.02] border border-white/10 rounded-[2.5rem] p-8 md:p-10 relative h-full flex flex-col transition-colors duration-500 min-w-[320px] hover:bg-white/[0.04]">
                    <div className="flex flex-col justify-between items-start mb-6 gap-6">
                        <div className="flex-shrink-0">
                            <h3 className="font-bold text-2xl text-white group-hover:text-magic-royal transition-colors duration-500 mb-2 whitespace-nowrap">Abonnement Mensuel</h3>
                            <p className="text-gray-400 text-sm whitespace-nowrap">Découvrez l'Atelier sans engagement.</p>
                        </div>

                        <div className="flex items-baseline gap-1 flex-shrink-0">
                            <span className="font-black text-white text-4xl lg:text-5xl transition-all duration-300">
                                {monthlyProduct?.price_label || "9,99€"}
                            </span>
                            <span className="text-gray-500 font-medium">/mois</span>
                        </div>
                    </div>

                    <div className="mb-8 flex-1">
                        <ul className="space-y-4">
                            <li className="flex items-center gap-3 text-gray-300">
                                <CheckIcon />
                                <span>L'intégralité du contenu</span>
                            </li>
                            <li className="flex items-center gap-3 text-gray-300">
                                <CheckIcon />
                                <span>Nouvelles sorties incluses</span>
                            </li>
                            <li className="flex items-center gap-3 text-gray-300">
                                <CheckIcon />
                                <span>Annulable en un simple clic</span>
                            </li>
                            <li className="flex items-center gap-3 text-gray-300">
                                <CheckIcon />
                                <span>Accès multi-écrans</span>
                            </li>
                        </ul>
                    </div>

                    <div className="mt-auto">
                        <SubscribeButton
                            priceId={monthlyProduct?.stripe_price_id}
                            productId={monthlyProduct?.id}
                            space="adults"
                            userLoggedIn={userLoggedIn}
                            buttonText="Commencer l'essai"
                            className="w-full text-white border transition-colors duration-500 py-4 text-lg bg-white/5 border-white/20 hover:bg-white/10"
                        />
                    </div>
                </div>
            </div>

            {/* LE CERCLE - RIGHT SIDE */}
            <div className="relative group flex-1 flex flex-col justify-end overflow-hidden origin-bottom">
                {/* Glow Behind */}
                <div className="absolute -inset-1 bg-gradient-to-br from-magic-royal/30 to-amber-700/10 rounded-[2.5rem] blur-xl opacity-80 pointer-events-none"></div>

                <div className="relative bg-[#0A0A0E] border border-white/10 rounded-[2.5rem] p-8 md:p-10 h-full flex flex-col min-w-[320px] transition-colors duration-500 shadow-2xl z-10">
                    {/* Inner Glass border */}
                    <div className="absolute inset-0 border border-white/5 rounded-[2.5rem] pointer-events-none"></div>

                    <div className="flex flex-col justify-between items-start mb-8 gap-6">
                        <div className="flex-shrink-0">
                            <div className="flex items-center gap-3 mb-2">
                                <Crown className="w-8 h-8 text-magic-royal flex-shrink-0" />
                                <h2 className="font-black text-white tracking-tight whitespace-nowrap text-3xl md:text-4xl transition-all duration-300">
                                    Abonnement Annuel
                                </h2>
                            </div>
                            <p className="text-magic-royal/80 font-medium tracking-wide whitespace-nowrap text-sm lg:text-base">
                                Économisez 2 mois d'abonnement.
                            </p>
                        </div>

                        <div className="flex flex-col items-start flex-shrink-0">
                            <div className="flex items-baseline gap-2">
                                <span className="font-black text-white tracking-tighter text-4xl lg:text-5xl transition-all duration-300">
                                    {yearlyProduct?.price_label || "99,99€"}
                                </span>
                            </div>
                            <div className="text-gray-400 font-medium mt-1 whitespace-nowrap">facturé annuellement</div>

                            <div className="mt-2">
                                <div className="inline-block bg-magic-royal/10 text-magic-royal border border-magic-royal/20 px-3 py-1 rounded-md text-xs font-bold whitespace-nowrap">
                                    Soit 8,33€/mois
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="mb-8 flex-1">
                        <ul className="space-y-4">
                            <li className="flex items-start gap-4">
                                <div className="w-8 h-8 rounded-full bg-white/5 flex flex-shrink-0 items-center justify-center border border-white/10">
                                    <PlayCircle className="w-4 h-4 text-magic-royal" />
                                </div>
                                <span className="text-gray-300 text-base">Accès illimité à <strong className="text-white">l'Atelier</strong></span>
                            </li>
                            <li className="flex items-start gap-4">
                                <div className="w-8 h-8 rounded-full bg-white/5 flex flex-shrink-0 items-center justify-center border border-white/10">
                                    <Sparkles className="w-4 h-4 text-magic-royal" />
                                </div>
                                <span className="text-gray-300 text-base"><strong className="text-white">Nouveautés régulières</strong></span>
                            </li>
                            <li className="flex items-start gap-4">
                                <div className="w-8 h-8 rounded-full bg-magic-royal/10 flex flex-shrink-0 items-center justify-center border border-magic-royal/20">
                                    <Star className="w-4 h-4 text-magic-royal" />
                                </div>
                                <span className="text-gray-300 text-base">Accès aux <strong className="text-white">Lives privés</strong></span>
                            </li>
                            <li className="flex items-start gap-4">
                                <div className="w-8 h-8 rounded-full bg-magic-royal/10 flex flex-shrink-0 items-center justify-center border border-magic-royal/20">
                                    <ShieldCheck className="w-4 h-4 text-magic-royal" />
                                </div>
                                <span className="text-gray-300 text-base"><strong className="text-white">Ressources exclusives</strong></span>
                            </li>
                        </ul>
                    </div>

                    <div className="mt-auto">
                        <SubscribeButton
                            priceId={yearlyProduct?.stripe_price_id}
                            productId={yearlyProduct?.id}
                            space="adults"
                            userLoggedIn={userLoggedIn}
                            buttonText="Rejoindre l'Atelier"
                            className="w-full py-4 text-lg bg-gradient-to-r from-magic-royal to-yellow-600 hover:from-blue-400 hover:to-yellow-500 text-black shadow-[0_0_40px_rgba(255,215,0,0.3)] border-none font-bold"
                        />
                    </div>
                </div>
            </div>

        </div>
    );
}

function CheckIcon() {
    return (
        <svg className="w-5 h-5 text-magic-royal flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
        </svg>
    )
}
